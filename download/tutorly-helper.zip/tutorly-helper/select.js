// Drag a box on the page; returns its position (or null if Esc). Removes itself afterwards.
(() => new Promise((resolve) => {
  const layer = document.createElement("div");
  const box = document.createElement("div");
  const tip = document.createElement("div");
  Object.assign(layer.style, { position: "fixed", inset: "0", zIndex: 2147483646, cursor: "crosshair", background: "rgba(10,10,14,.35)" });
  Object.assign(box.style, { position: "fixed", border: "2px solid #FFD633", background: "rgba(255,255,255,.08)", boxShadow: "0 0 0 9999px rgba(10,10,14,.25)", display: "none", pointerEvents: "none" });
  Object.assign(tip.style, { position: "fixed", top: "18px", left: "50%", transform: "translateX(-50%)", padding: "10px 16px", borderRadius: "999px", background: "#161616", color: "#fff", font: "600 14px/1.3 system-ui, Segoe UI, sans-serif", pointerEvents: "none" });
  tip.textContent = "Drag a box around the question · Esc to cancel";
  layer.append(box, tip);
  document.documentElement.appendChild(layer);
  let sx = 0, sy = 0, down = false;
  const done = (v) => { layer.remove(); window.removeEventListener("keydown", key, true); resolve(v); };
  const key = (e) => { if (e.key === "Escape") { e.preventDefault(); done(null); } };
  window.addEventListener("keydown", key, true);
  layer.addEventListener("mousedown", (e) => { down = true; sx = e.clientX; sy = e.clientY; box.style.display = "block"; layer.style.background = "transparent"; tip.style.display = "none"; e.preventDefault(); });
  layer.addEventListener("mousemove", (e) => {
    if (!down) return;
    const x = Math.min(sx, e.clientX), y = Math.min(sy, e.clientY), w = Math.abs(e.clientX - sx), h = Math.abs(e.clientY - sy);
    Object.assign(box.style, { left: x + "px", top: y + "px", width: w + "px", height: h + "px" });
  });
  layer.addEventListener("mouseup", (e) => {
    if (!down) return;
    down = false;
    const x = Math.min(sx, e.clientX), y = Math.min(sy, e.clientY), w = Math.abs(e.clientX - sx), h = Math.abs(e.clientY - sy);
    if (w < 8 || h < 8) { box.style.display = "none"; layer.style.background = "rgba(10,10,14,.35)"; tip.style.display = "block"; return; }
    done({ x, y, w, h, dpr: window.devicePixelRatio || 1 });
  });
}))();
