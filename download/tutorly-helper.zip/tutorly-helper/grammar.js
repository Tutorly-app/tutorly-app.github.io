// Tutorly Helper: grammar help while typing on websites.
// When you pause typing in a text box, its text is checked by the Tutorly app on this computer, and a small
// badge shows how many fixes there are. Click it to see each fix with a reason, and apply them.
// Never runs in password, payment, code or login boxes. Nothing is sent anywhere except the Tutorly app.
(() => {
  if (window.__tutorlyGrammar) return;
  window.__tutorlyGrammar = true;
  if (/^(docs|sheets|slides)\.google\.com$/.test(location.hostname) && /^\/(document|spreadsheets|presentation)/.test(location.pathname)) return; // drawn on a canvas: can't be read

  const SENSITIVE = /pass|pwd|card|cvv|cvc|ssn|social.?sec|otp|one.?time|pin\b|iban|routing|account.?num|secret|token|login|user.?name/i;
  const state = new WeakMap(); // element -> { last, at, fixes, timer, busy }
  let active = null, off = false, host = null, ui = null;

  function editable(el) {
    if (!el || el.nodeType !== 1) return null;
    if (el.tagName === "TEXTAREA") return el;
    if (el.tagName === "INPUT") return /^(text|search|)$/i.test(el.type || "") ? el : null;
    const ce = el.closest && el.closest('[contenteditable=""],[contenteditable="true"],[role="textbox"]');
    return ce || null;
  }
  function sensitive(el) {
    if (el.tagName === "INPUT" && el.type === "password") return true;
    const ac = (el.getAttribute("autocomplete") || "") + " " + (el.name || "") + " " + (el.id || "") + " " + (el.getAttribute("aria-label") || "") + " " + (el.placeholder || "");
    if (SENSITIVE.test(ac)) return true;
    if (el.closest && el.closest("form") && el.closest("form").querySelector('input[type="password"]')) return true;
    if (el.closest && el.closest(".monaco-editor,.CodeMirror,.cm-editor,.ace_editor,[data-language]")) return true; // code editors
    return false;
  }
  const textOf = (el) => (el.tagName === "TEXTAREA" || el.tagName === "INPUT" ? el.value : el.innerText || "").slice(0, 6000);

  // ---------- the badge and panel (in a shadow root, so websites can't restyle or read them) ----------
  function makeUi() {
    host = document.createElement("tutorly-grammar");
    Object.assign(host.style, { position: "fixed", zIndex: 2147483646, left: "0", top: "0", width: "0", height: "0" });
    const root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `<style>
      *{box-sizing:border-box;font:500 13px/1.35 system-ui,Segoe UI,sans-serif}
      .b{position:fixed;width:26px;height:26px;border-radius:50%;border:0;cursor:pointer;display:grid;place-items:center;font-weight:800;font-size:12px;color:#fff;background:#161616;box-shadow:0 4px 14px rgba(0,0,0,.25);transition:transform .2s,background .2s;opacity:.95}
      .b:hover{transform:scale(1.1)} .b.ok{background:#0E8E55} .b.fix{background:#D9362B} .b.wait{background:#6440F0} .b.idle{background:#8A8C92}
      .b.wait::after{content:"";width:10px;height:10px;border-radius:50%;border:2px solid #fff;border-top-color:transparent;animation:s .8s linear infinite}
      @keyframes s{to{transform:rotate(360deg)}}
      .p{position:fixed;width:340px;max-height:360px;overflow:auto;background:#fff;color:#161616;border-radius:16px;box-shadow:0 18px 50px rgba(0,0,0,.28);padding:12px;display:none}
      .p.on{display:block;animation:in .18s ease-out} @keyframes in{from{opacity:0;transform:translateY(6px)}}
      .h{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;font-weight:800}
      .i{padding:9px 10px;border-radius:12px;background:#F4F3EF;margin-bottom:8px}
      del{color:#8A8C92} ins{text-decoration:none;font-weight:750} .w{color:#5E6066;font-size:12px;margin-top:3px}
      button.f{border:0;border-radius:999px;padding:5px 12px;font-weight:750;cursor:pointer;background:#161616;color:#fff;margin-top:6px}
      button.g{border:0;background:none;color:#5E6066;cursor:pointer;font-weight:700}
    </style><button class="b idle" title="Tutorly grammar help"></button><div class="p"></div>`;
    document.documentElement.appendChild(host);
    const badge = root.querySelector(".b"), panel = root.querySelector(".p");
    badge.addEventListener("mousedown", (e) => e.preventDefault()); // keep the cursor in the text box
    badge.addEventListener("click", () => { panel.classList.toggle("on"); draw(); place(); });
    return { root, badge, panel };
  }
  function place() {
    if (!ui || !active || !active.isConnected) return;
    const r = active.getBoundingClientRect();
    const vis = r.width > 40 && r.height > 14 && r.bottom > 0 && r.top < innerHeight;
    ui.badge.style.display = vis ? "grid" : "none";
    const x = Math.min(innerWidth - 34, r.right - 32), y = Math.min(innerHeight - 34, r.bottom - 32);
    ui.badge.style.left = x + "px"; ui.badge.style.top = y + "px";
    ui.panel.style.left = Math.max(8, Math.min(innerWidth - 350, x - 310)) + "px";
    ui.panel.style.top = (y > 380 ? y - 368 : y + 34) + "px";
    if (!vis) ui.panel.classList.remove("on");
  }
  function setBadge(kind, label, title) {
    if (!ui) ui = makeUi();
    ui.badge.className = "b " + kind;
    ui.badge.textContent = label || "";
    ui.badge.title = title || "";
    place();
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }
  function draw() {
    if (!ui || !active) return;
    const st = state.get(active) || {};
    const fixes = (st.fixes || []).filter((f) => !f.done);
    if (!fixes.length) { ui.panel.innerHTML = `<div class="h">No mistakes found <button class="g x">Close</button></div>`; }
    else ui.panel.innerHTML = `<div class="h">${fixes.length} fix${fixes.length > 1 ? "es" : ""} <span><button class="f all">Fix all</button> <button class="g x">Close</button></span></div>` +
      fixes.map((f, i) => `<div class="i"><del>${esc(f.from)}</del> → <ins>${esc(f.to)}</ins><div class="w">${esc(f.why || "")}</div><button class="f one" data-i="${i}">Fix</button></div>`).join("");
    ui.panel.querySelectorAll("button").forEach((b) => b.addEventListener("mousedown", (e) => e.preventDefault()));
    const x = ui.panel.querySelector(".x"); if (x) x.onclick = () => ui.panel.classList.remove("on");
    const all = ui.panel.querySelector(".all"); if (all) all.onclick = () => { fixes.forEach((f) => apply(f)); draw(); badgeFor(active); };
    ui.panel.querySelectorAll(".one").forEach((b) => (b.onclick = () => { apply(fixes[Number(b.dataset.i)]); draw(); badgeFor(active); }));
  }

  // ---------- applying a fix in the page's text box ----------
  function apply(f) {
    const el = active;
    if (!el || !f || f.done) return;
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      const i = el.value.indexOf(f.from);
      if (i < 0) return;
      el.focus();
      el.setRangeText(f.to, i, i + f.from.length, "end");
      el.dispatchEvent(new Event("input", { bubbles: true }));
      f.done = true;
      return;
    }
    // contenteditable: find the words in one text node, select them, and type the fix (keeps the editor's undo)
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const i = n.nodeValue.indexOf(f.from);
      if (i < 0) continue;
      const range = document.createRange();
      range.setStart(n, i); range.setEnd(n, i + f.from.length);
      const sel = getSelection(); sel.removeAllRanges(); sel.addRange(range);
      if (!document.execCommand("insertText", false, f.to)) { range.deleteContents(); range.insertNode(document.createTextNode(f.to)); }
      f.done = true;
      return;
    }
  }
  function badgeFor(el) {
    const st = state.get(el);
    if (!st || !st.fixes) return setBadge("idle", "", "Tutorly checks your writing when you pause typing");
    const left = st.fixes.filter((f) => !f.done).length;
    setBadge(left ? "fix" : "ok", left ? String(left) : "✓", left ? left + " possible fix" + (left > 1 ? "es" : "") + " (click to see)" : "No mistakes found");
  }

  // ---------- checking ----------
  function check(el) {
    const st = state.get(el);
    const text = textOf(el);
    if (off || text.trim().length < 25 || !/[a-z]{3}/i.test(text) || text === st.last) return;
    const wait = 6000 - (Date.now() - (st.at || 0));
    if (wait > 0) { clearTimeout(st.timer); st.timer = setTimeout(() => check(el), wait); return; }
    st.last = text; st.at = Date.now(); st.busy = true;
    if (el === active) setBadge("wait", "", "Checking…");
    chrome.runtime.sendMessage({ type: "grammar", text }, (res) => {
      st.busy = false;
      if (chrome.runtime.lastError || !res) { if (el === active) setBadge("idle", "t", "Open the Tutorly app to get grammar help"); return; }
      if (res.off) { off = true; if (host) host.remove(); host = null; ui = null; return; }
      if (!res.ok) { if (el === active) setBadge("idle", "t", res.error || "Grammar help isn't available right now"); return; }
      if (textOf(el) !== text) return; // they kept typing; the next pause checks again
      st.fixes = (res.fixes || []).filter((f) => f.from && text.indexOf(f.from) >= 0);
      if (el === active) { badgeFor(el); if (ui.panel.classList.contains("on")) draw(); }
    });
  }

  document.addEventListener("focusin", (e) => {
    const el = editable(e.composedPath ? e.composedPath()[0] : e.target);
    if (!el || sensitive(el) || off) return;
    active = el;
    if (!state.has(el)) state.set(el, {});
    badgeFor(el);
  }, true);
  document.addEventListener("input", (e) => {
    const el = editable(e.composedPath ? e.composedPath()[0] : e.target);
    if (!el || el !== active || off) return;
    const st = state.get(el);
    clearTimeout(st.timer);
    st.timer = setTimeout(() => check(el), 1800);
  }, true);
  document.addEventListener("focusout", () => setTimeout(() => {
    if (ui && active && document.activeElement !== active && !(ui.panel.classList.contains("on"))) { ui.badge.style.display = "none"; }
  }, 200), true);
  addEventListener("scroll", place, true);
  addEventListener("resize", place);
})();
