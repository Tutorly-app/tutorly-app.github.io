Tutorly Helper (browser extension for Chrome and Microsoft Edge)

Right-click a question on any web page and choose "Ask Tutorly" to get it explained in the Tutorly app.
- Select text, right-click: Ask Tutorly: "..."
- Right-click a picture: Ask Tutorly about this picture
- Right-click the page, click the Tutorly button, or press Alt+Shift+T: snip part of the page
The Tutorly app must be open on the same computer. The extension only talks to Tutorly on this computer (127.0.0.1).
