// Tutorly Helper: adds "Ask Tutorly" to the right-click menu. The question goes to the Tutorly app on this
// computer (127.0.0.1 only), which comes to the front and explains it. Nothing is sent anywhere else.
const PORTS = [47811, 47812, 47813, 47814, 47815];

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "ask-text", title: "Ask Tutorly: “%s”", contexts: ["selection"] });
    chrome.contextMenus.create({ id: "ask-image", title: "Ask Tutorly about this picture", contexts: ["image"] });
    chrome.contextMenus.create({ id: "snip", title: "Snip part of this page for Tutorly", contexts: ["page", "frame", "link", "editable", "video"] });
  });
});

// Lets the Tutorly app know the helper is installed (shown in Tutorly's Settings).
async function hello() {
  for (const port of PORTS) { try { const r = await fetch("http://127.0.0.1:" + port + "/tutorly/ping"); if (r.ok) return; } catch (e) {} }
}
chrome.runtime.onStartup.addListener(hello);
chrome.runtime.onInstalled.addListener(hello);

async function send(payload) {
  for (const port of PORTS) {
    try {
      const r = await fetch("http://127.0.0.1:" + port + "/tutorly/ask", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (r.status === 403 || r.status === 404) continue; // another program on that port
      const j = await r.json().catch(() => ({}));
      if (r.ok && j.ok) return { ok: true };
      return { ok: false, error: j.error || "Tutorly couldn't take that question." };
    } catch (e) { /* not on this port */ }
  }
  return { ok: false, error: "Open the Tutorly app on this computer first, then try again." };
}

/** A small message on the page itself (no extra permissions needed). */
async function toast(tabId, text, good) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      args: [text, good],
      func: (text, good) => {
        const old = document.getElementById("__tutorly_toast");
        if (old) old.remove();
        const d = document.createElement("div");
        d.id = "__tutorly_toast";
        d.textContent = text;
        Object.assign(d.style, { position: "fixed", zIndex: 2147483647, right: "20px", bottom: "20px", padding: "12px 18px", borderRadius: "999px", font: "600 14px/1.3 system-ui, Segoe UI, sans-serif",
          background: good ? "#161616" : "#B42318", color: "#fff", boxShadow: "0 8px 30px rgba(0,0,0,.25)", transition: "opacity .3s, transform .3s", opacity: "0", transform: "translateY(8px)" });
        document.documentElement.appendChild(d);
        requestAnimationFrame(() => { d.style.opacity = "1"; d.style.transform = "none"; });
        setTimeout(() => { d.style.opacity = "0"; setTimeout(() => d.remove(), 350); }, good ? 2200 : 5000);
      }
    });
  } catch (e) { /* pages like the Chrome Web Store don't allow this */ }
}

async function snip(tab) {
  let rect;
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["select.js"] });
    rect = res && res.result;
  } catch (e) { return toast(tab.id, "Tutorly can't snip this page. Use the Tutorly snip shortcut instead.", false); }
  if (!rect) return; // cancelled
  await new Promise((r) => setTimeout(r, 120)); // let the selection box disappear first
  const shot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
  const bmp = await createImageBitmap(await (await fetch(shot)).blob());
  const k = rect.dpr || 1;
  const sx = Math.max(0, Math.round(rect.x * k)), sy = Math.max(0, Math.round(rect.y * k));
  const sw = Math.min(bmp.width - sx, Math.round(rect.w * k)), sh = Math.min(bmp.height - sy, Math.round(rect.h * k));
  const c = new OffscreenCanvas(sw, sh);
  c.getContext("2d").drawImage(bmp, sx, sy, sw, sh, 0, 0, sw, sh);
  const blob = await c.convertToBlob({ type: "image/png" });
  const data = await new Promise((r) => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(blob); });
  const res = await send({ imageData: data, title: tab.title || "" });
  toast(tab.id, res.ok ? "Sent to Tutorly ✓" : res.error, res.ok);
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab || tab.id == null) return;
  if (info.menuItemId === "snip") return snip(tab);
  let payload;
  if (info.menuItemId === "ask-text") payload = { text: info.selectionText || "", title: tab.title || "" };
  else if (info.menuItemId === "ask-image") payload = /^data:image\//.test(info.srcUrl || "") ? { imageData: info.srcUrl, title: tab.title || "" } : { imageUrl: info.srcUrl || "", title: tab.title || "" };
  if (!payload) return;
  const res = await send(payload);
  toast(tab.id, res.ok ? "Sent to Tutorly ✓" : res.error, res.ok);
});

chrome.action.onClicked.addListener((tab) => snip(tab));
chrome.commands.onCommand.addListener(async (cmd, tab) => { if (cmd === "snip" && tab) snip(tab); });
